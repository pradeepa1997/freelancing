class q1{
    static void main(string args:Array){
        
    }
}