New created shape input format


text <px> <py> <vx> <vy> <filled?> <maxWidth> <string> <r> <g> <b> <insertaion time>

<px> <py> -The strating position of the shape in the plane

<vx> <vy> -The velocity of the shapes as a vector 

<filled?> - True if the shape is filled and false otherwise

<maxWidth> - max width should be string 

<string> -string will display

<r> <g> <b> -The colour of the shape 

<insertaion time> -time in milliseconds since the start of the programe after 