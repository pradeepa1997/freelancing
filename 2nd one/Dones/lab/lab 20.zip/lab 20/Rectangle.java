    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab20;

import java.awt.*;
/* Rectangle.java
 * Lab 20, COMP160,  2019
 * 
 * graphical representation of a rectangle
 * with a fill, colour, x, y, width, height
 */

public class Rectangle{
  private int x;  // x location;
  private int y;  // y location;
  private Color shade;  // colour of Rectangle
  private int width; //width of Rectangle
  private int height;//height of Rectangle
  private boolean fill; //drawRect false or fillRect true
  private static int totalcount;
  private int thiscount;
  
  /**constructor for Rectangle*/
  public Rectangle(int fill, int shade,int x, int y , int width, int height){
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    totalcount = totalcount+1;
    thiscount= totalcount;
    
    if(shade==1){
        this.shade = Color.red;
    }else if(shade==2){
      this.shade=Color.blue;
   }else{
        this.shade=Color.green;
          
      }
     
    if(fill==1){
        this.fill= true;//true=1   
    }else{
        this.fill=false;//false=0;
    }
    
  }
  
 /**draw this rectangle
@param g a Graphics object*/
    public void draw(Graphics g){
       
    int fontSize = 12;
    g.setFont(new Font("TimesRoman", Font.PLAIN, fontSize));//set font size
    g.setColor(Color.black);//set the color of text
    g.drawString(thiscount+"of"+totalcount, x, y);//set the position of the text
    
    
        g.setColor(shade);
        if (fill ){
            g.fillRect(x, y, width, height);
        } else  {
            g.drawRect(x, y, width, height);
        }
    }
  
}