/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab20;
import java.io.*;
import java.awt.*;
import java.util.Scanner;
import javax.swing.*;

public class FilePanel extends JPanel{
    //can be make 50 instance of rectangles
  private Rectangle[] drawObjects = new Rectangle [50];
  private int count;
  Scanner sc;
  
  /**constructor instantiates 6 Rectangle objects*/
  public FilePanel(){  
      
      try{
          File file = new File("C:\\Users\\Supun\\Desktop\\text.txt");//file path
       sc = new Scanner(file);
   
         }catch(FileNotFoundException e){
          System.out.println("File not found.Check the file name and location");
          System.exit(1);
          
          }//reading the file
      
      while(sc.hasNext()){
          
          String inputline = sc.nextLine();
          if(inputline.matches("\\d+ \\d+ \\d+ \\d+ \\d+ \\d+")){
           
              Scanner s = new Scanner(inputline);
                int fill_or_draw = s.nextInt();
                int color = s.nextInt();
                int x = s.nextInt();
                int y = s.nextInt();
                int width = s.nextInt();
                int lenth =s.nextInt();

                 drawObjects[count] = new Rectangle(fill_or_draw,color, x, y,width,lenth);
                 count++;
          }//while loop for reading the file line by line
          
           
        }
    setPreferredSize(new Dimension(600,400));//set the size of the frame
    setBackground(Color.yellow);
  }
  
  /**each Rectangle will draw itself*/
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    for(int i = 0; i < count; i++){
      drawObjects[i].draw(g);
    } 
  }
}

