/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab20;

import javax.swing.*;

public class FileApp{
  
 
  public static void main(String[]args){
    JFrame fileFrame = new JFrame();
    fileFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    fileFrame.getContentPane().add(new FilePanel());
    fileFrame.pack();
    fileFrame.setVisible(true);
    fileFrame.setTitle("File Reading Lab 20");
  }
  
}