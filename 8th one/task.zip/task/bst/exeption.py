class ItemExistsException(Exception):
    pass
        

class NotFoundException(Exception):
    pass