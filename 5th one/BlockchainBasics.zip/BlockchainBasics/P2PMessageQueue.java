/**
 * This Queue maintains the queue of messages coming from connected clients.
 */
public class P2PMessageQueue {

    private P2PMessage head = null;
    private P2PMessage tail = null;


    /**
     * This method allows adding a message object to the existing queue.
     * @param oMessage
     */
    public synchronized void enqueue(P2PMessage oMessage){

		#####################
		### ADD CODE HERE ###
		#####################
    }


    /**
     * This method allows removing a message object from the existing queue.
     * @return
     */
    public synchronized P2PMessage dequeue(){

		#####################
		### ADD CODE HERE ###
		#####################
    }


    public boolean hasNodes(){

		#####################
		### ADD CODE HERE ###
		#####################
    }
}

