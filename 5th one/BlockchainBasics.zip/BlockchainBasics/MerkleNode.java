/**
 * This class simply holds a single Merkle Node's values.
 */
public class MerkleNode {


    String sHash;
    MerkleNode oLeft;
    MerkleNode oRight;
}
